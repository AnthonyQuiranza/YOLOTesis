
Tesis - v3 2022-01-27 8:35am
==============================

This dataset was exported via roboflow.ai on January 27, 2022 at 1:42 PM GMT

It includes 130 images.
Hoja are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 1 versions of each source image:
* Randomly crop between 0 and 12 percent of the image


